_____________________________________________________________________________
______/\/\______________________________/\/\__________________/\/\____/\/\___
_____________/\/\/\/\______/\/\/\/\__/\/\/\/\/\__/\/\/\______/\/\____/\/\____ 
____/\/\____/\/\__/\/\__/\/\/\/\______/\/\__________/\/\____/\/\____/\/\_____  
___/\/\____/\/\__/\/\________/\/\____/\/\______/\/\/\/\____/\/\____/\/\______   
__/\/\/\__/\/\__/\/\__/\/\/\/\______/\/\/\____/\/\/\/\/\__/\/\/\__/\/\/\_____    
_____________________________________________________________________________     

1) download pure data 
https://puredata.info/downloads/pure-data

2) install pure data

2) open pure data

3) install ofelia
Help -> Find externals -> search for "ofelia" and Install
Ignore if SHA256 verification failed

_________________________________________
_________________________________________
_____/\/\__/\/\__/\/\__/\/\__/\/\/\/\____ 
____/\/\/\/\____/\/\__/\/\__/\/\__/\/\___  
___/\/\________/\/\__/\/\__/\/\__/\/\____   
__/\/\__________/\/\/\/\__/\/\__/\/\_____    
_________________________________________     

1) open filter.pd

2) Enable DSP
Media -> DSP on

_______________________________________________________________________
______/\/\/\/\/\/\__/\/\____/\/\______/\/\_____________________________
_____/\/\__________________/\/\____/\/\/\/\/\____/\/\/\____/\/\__/\/\__
____/\/\/\/\/\____/\/\____/\/\______/\/\______/\/\/\/\/\__/\/\/\/\_____
___/\/\__________/\/\____/\/\______/\/\______/\/\________/\/\__________
__/\/\__________/\/\/\__/\/\/\____/\/\/\______/\/\/\/\__/\/\___________
_______________________________________________________________________

press left button and drag the cursor to draw with the current tool type
click the mouse wheel to select the next parameter
the selected parameter is highlighted in magenta
roll the mouse wheel to change the selected parameter
press right button and drag the cursor to create up to six image reading filters
press right button and immediately release to remove the image reading filter under the cursor

fractal:
while drawing with the fractal tool, press the mouse wheel and drag the cursor to change the coordinates of the scale center

spectre:
draws a spectrogram of the output signal
use spectre's dynamic mode to draw up to six real-time changing spectrograms

settings:
press the mouse wheel for at least six seconds to open the settings menu

camera:
change the camera scale parameter in settings if the camera scale is incorrect

